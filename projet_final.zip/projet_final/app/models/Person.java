package models ;

import java.util.*;
import io.ebean.*;
import javax.persistence.*;


@Entity
public class Person extends Model {
  
	private static final long serialVersionUID = 1L;

	@Id
	public long id;    
	public String firstname = null;
	private String mdp = null;
	private String mail = null;
	public boolean inscrit;//false = anonyme, true = membre
		
		public Person(String firstname,  String mdp, String mail){ // nouveau membre
			this.firstname=firstname;
			this.inscrit=true;
			this.mdp=mdp;
			this.mail=mail;
		}
		
		public Person(String firstname){//nouvelle anonyme
			this.firstname=firstname;
			this.inscrit=false;
		}
		
		public String getFirstname(){
			return this.firstname;
		}
		
		
		public void setFirstname(String firstname){
			this.firstname = firstname;
		}
		
		public static Finder<Long, Person> find = new Finder<Long,Person>(Person.class);
}