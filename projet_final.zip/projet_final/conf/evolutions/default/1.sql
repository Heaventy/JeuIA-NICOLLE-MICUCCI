# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table jeux (
  id                            bigint auto_increment not null,
  nb_joueurs                    integer not null,
  joueurs_max                   integer not null,
  constraint pk_jeux primary key (id)
);

create table person (
  id                            bigint auto_increment not null,
  firstname                     varchar(255),
  mdp                           varchar(255),
  mail                          varchar(255),
  inscrit                       boolean default false not null,
  constraint pk_person primary key (id)
);


# --- !Downs

drop table if exists jeux;

drop table if exists person;

